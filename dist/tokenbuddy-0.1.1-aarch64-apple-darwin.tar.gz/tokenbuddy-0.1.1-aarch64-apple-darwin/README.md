# TokenBuddy

TokenBuddy LLM 服务市场 P0 实现 — **seller-core 信任引擎** + **buyer-core 共享买家库**。

- **Seller** 以 HTTP 服务形式运行，对接 OpenAI-compatible Chat Completions / Responses 上游推理服务。
- **Buyer** 通过 CLI（或 OpenAI 兼容反向代理）完成 支付 → token 购买 → bearer auth → 推理调用 → 信用扣减 的完整流程。

支付模式：

| 模式 | 说明 | 默认 |
|------|------|------|
| **mock** | 本地开发/测试，任意字符串作为凭证 | 关 |
| **clawtip** | 接入 ClawTip 京东钱包，SM4 加密验证真实付款 | **开** |

---

## 📐 项目架构

### 1. Workspace 结构

```
TokenBuddy/
├── crates/
│   ├── contracts/          # ★ 共享 wire types（manifest / purchase / balance / errors）
│   ├── clawtip-protocol/   #   ClawTip 订单/credential 协议结构
│   ├── seller-core/        # ★ Seller HTTP 服务库
│   │                       #   manifest / purchase / ledger / inference / capacity / errors
│   ├── buyer-core/         # ★ Buyer 共享库（Phase 2 抽出）
│   │                       #   token::TokenStore / payment::ClawtipPreflight
│   ├── cli-seller/         #   tb-seller —— serve / status / ledger / revoke-class
│   ├── cli-buyer/          #   tb —— seller / payment / purchase / proxy / chat
│   ├── buyer-daemon/       #   tb-proxyd —— buyer 侧 proxy RPC 控制面
│   ├── cli-admin/          #   tb-admin —— seller 远程运维 CLI
│   └── wallet-bootstrap/   #   tb-wallet-bootstrap —— 独立 ClawTip 钱包激活服务
├── docs/                   #   设计方案 / 实施计划 / 迁移记录
└── scripts/
    └── demo-landing-page.sh   # 一键端到端演示
```

### 2. 运行拓扑

```
┌──────────────┐  POST /v1/chat/completions       ┌──────────────────┐
│  下游 LLM    │ ───────────────────────────────► │  Buyer Proxy     │
│  Codex /     │                                  │  127.0.0.1:15721 │
│  Opencode /  │ ◄─────── 200 OK + 流量透明 ───── │  (tb proxy      │
│  curl …      │                                  │   start)         │
└──────────────┘                                  └──────┬───────────┘
                                                         │
                                  reuse / ensure token   │ buyer-core::TokenStore
                                  缓存命中 → 直接转发    │ (~/.tokenbuddy/buyer/tokens/)
                                  缓存失效 → 自动购买    │
                                                         ▼
                            POST /purchase/create      ┌──────────────────┐
                            POST /purchase/complete    │  Seller HTTP     │
                            POST /v1/chat/completions  │  127.0.0.1:8080  │
                                                       │  (tb-seller      │
                                                       │   serve)         │
                                                       └──────┬───────────┘
                                                              │
                                              SQLite WAL ledger │ 上游 OpenAI-compat
                                              (pre-reserve →     │ DashScope / OpenAI /
                                               settle → audit)   ▼ Anthropic / DeepSeek
                                                          ┌──────────────┐
                                                          │  Upstream    │
                                                          └──────────────┘
```

### 3. 关键数据流

1. **预留 (pre-reserve)** — Seller 在 `/purchase/create` 时把 `credit_micros` 在账本上 reserve，立即返回 `purchase_id` + 支付指令（ClawTip 订单参数）。
2. **付款 (pay)** — Buyer 在本机调起 `openclaw` / `@clawtip/clawtip-cli`，把 `payCredential` 回写订单文件。
3. **激活 (complete)** — Buyer `/purchase/complete` 携带 `payCredential` 提交，Seller 验证 SM4 → 签发 access_token（带 `token_class=model:<id>`）→ ledger 状态从 reserved → active。
4. **推理 (chat)** — Buyer 用 access_token + `requestId` 调用 `/v1/chat/completions`，Seller pre-reserve 单次预算 → 转发上游 → 收到 `usage` 后按 `markup_ratio` 结算实际花费 → ledger deduct。
5. **缓存 (cache)** — Buyer 把 access_token 缓存到 `~/.tokenbuddy/buyer/tokens/<sha256(seller:model)>.json`，下次相同 (seller, model) 跳过 1~3 步直接走第 4 步。

### 4. 错误码 & retryClass

所有错误码定义在 `contracts/src/errors.rs`（Rust enum），`retryClass` 由 `code` 编译时派生（不可手设）。客户端用 `retryClass` 做重试决策，`code` 做日志/展示。常用错误码：

| code | retryClass | 含义 |
|------|------------|------|
| `invalid_or_expired_token` | `not_retryable` | token 撤销/过期 → buyer 应重新购买 |
| `busy_capacity` | `retryable_with_backoff` | seller 满载 |
| `streaming_not_supported` | `not_retryable` | P0 暂不支持 `stream:true` |
| `request_id_required` | `not_retryable` | chat 必须带 `requestId` 幂等键 |
| `fail_closed` | `fail_closed` | seller 内部进入 fail-closed 状态 |

---

## 🚀 快速开始

### 0. 前置说明

- **发布模式安装**：无特殊前置环境要求。macOS、Linux、Windows 均支持一键预编译安装与运行。
- **ClawTip 支付模式（可选）**：本地调起钱包需安装并配置好 `openclaw` 客户端。
- **源码编译开发模式（可选）**：需要安装 Rust stable 编译工具链（仅当您想从源码手动构建时需要）。

### 1. 跨平台一键安装（推荐）

通过 `cargo-dist` 发布的免编译预编译二进制，您可以快速在本地部署 `tb` 客户端前端。

#### 💻 macOS / Linux
在终端运行以下命令，系统会自动识别 CPU 架构并完成一键安装：
```bash
curl --proto '=https' --tlsv1.2 -LsSf https://github.com/zhouchangui/TokenBuddy/releases/latest/download/tb-installer.sh | sh
```

#### 🪟 Windows
使用 PowerShell 运行以下命令，会自动配置系统环境变量并完成一键安装：
```powershell
irm https://github.com/zhouchangui/TokenBuddy/releases/latest/download/tb-installer.ps1 | iex
```

> [!TIP]
> 一键安装完成后，您可以在终端直接使用 `tb` 命令。如果您是本地源码编译，可将下述示例中的 `tb` 替换为相应的路径 `./target/release/tb`。

安装包会随附 `config/defaults.toml`。首次运行时，`tb` 会按需把它初始化到共享数据目录
`~/.tokenbuddy/buyer/defaults.toml`；该文件只保存两个默认入口：

```toml
wallet_bootstrap_url = "https://tb-wallet-bootstrap.fly.dev"
seller_registry_url = "https://tb-wallet-bootstrap.fly.dev/sellers.json"
```

#### 本地 Buyer Portable 包

如果需要从当前源码构建一个可复制的 buyer 侧 portable 目录：

```bash
./scripts/build_buyer_portable.sh
./scripts/verify_buyer_portable.sh
```

产物位于 `dist/buyer-portable/`，包含 `bin/tb`、`bin/tb-proxyd` 和
`config/defaults.toml`。`tb` 会自动发现同目录的 `tb-proxyd`，并从上一级
`config/defaults.toml` 初始化 buyer defaults。

---

### 2. 使用与部署说明

> [!NOTE]
> 本项目包含 **Seller (卖家服务端 `tb-seller`)** 和 **Buyer (买家客户端前端 `tb` + `tb-proxyd`)** 两大组件。
> 本指南主要聚焦于 `tb` 客户端前端的配置与使用。如果您是模型服务提供商，需要自建 Seller 服务端，请参考独立的 [Seller 部署与运维指南](docs/seller-deployment.md)。

#### 2.1 运行一键端到端演示（需克隆代码）
如果您克隆了完整代码仓库并希望在本地同时模拟 Seller 和 Buyer 运行完整链路：
```bash
# 一键 build + 启动本地卖家端 + 买家端自检 + 启动本地 OpenAI 兼容反代并自动购买额度调用上游
./scripts/demo-landing-page.sh
```

#### 2.2 Buyer 本地支付自检

走 `buyer-core::ClawtipPreflight`，检查 openclaw / 版本 / 钱包配置：

```bash
tb payment doctor --seller http://127.0.0.1:8080
# [OK] openclaw on PATH: /opt/homebrew/bin/openclaw
# [OK] openclaw version: 2026.5.18 meets minimum 2026.5.18
# [OK] wallet config: found ~/.openclaw/configs/config.json with u length 128
```

#### 2.3 Buyer Proxy Daemon（控制面）

本地 `tb-proxyd` 是 RPC 控制面，默认监听 `127.0.0.1:17820`。CLI / UI 以后都只连它，不直接管 proxy 进程。

`tb proxy start|status|stop` 会先探测 daemon；如果本机 daemon 没运行，`tb` 会自动拉起 `tb-proxyd --bind-addr 127.0.0.1:17820` 并等待 `/health` ready。需要自定义控制面地址时，设置 `TOKENBUDDY_PROXYD_URL`；需要自定义 daemon 二进制时，设置 `TOKENBUDDY_PROXYD_BIN`。

#### 2.4 通过 RPC 启动 Buyer Proxy

Proxy 由 daemon 托管，`tb proxy start` 会发 RPC 给本地 daemon。daemon 内部使用隐藏的 `tb proxy run` 启动真实 proxy：

```bash
tb proxy start \
  --seller http://127.0.0.1:8080 \
  --model qwen-plus \
  --listen 127.0.0.1:15721 \
  --amount-usd 0.01
```

#### 2.5 发起推理

```bash
curl -sS -X POST http://127.0.0.1:15721/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "qwen-plus",
    "messages": [{"role":"user","content":"一句话介绍量子力学"}]
  }'
```

接入 Codex / Opencode / Claude Code：

```bash
export OPENAI_BASE_URL=http://127.0.0.1:15721   # codex / opencode
export ANTHROPIC_BASE_URL=http://127.0.0.1:15721   # claude code（待 P1 /v1/messages 落地）
# Authorization 任意字符串 —— proxy 自动替换为真实 seller token
```

#### 2.6 查询 / 停止状态

```bash
tb proxy status
tb proxy stop
curl -sS http://127.0.0.1:17820/health
```

UI / installer 可直接读取 daemon 的本地 JSON 控制面：

```bash
curl -sS http://127.0.0.1:17820/state
curl -sS http://127.0.0.1:17820/wallet/status
curl -sS http://127.0.0.1:17820/tokens
curl -sS -X POST http://127.0.0.1:17820/doctor/run \
  -H 'Content-Type: application/json' \
  -d '{"scope":"payment","method":"clawtip","fix":false}'
```

未迁移到 daemon 的有副作用流程会返回统一错误包络，不会伪造成功。

#### 2.7 验证 token 缓存命中

第二次相同 (seller, model) 请求 0 秒返回（不再走购买）：

```bash
curl -sS -X POST http://127.0.0.1:15721/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"qwen-plus","messages":[{"role":"user","content":"2+2=?"}]}'

# Buyer proxy 日志会打印：
# [buyer.token] reuse cached seller token <hash>...<redacted>
```

token 缓存位置：`~/.tokenbuddy/buyer/tokens/<sha256(seller:model)>.json`,
由 `buyer-core::token::TokenStore` 管理，可通过 `TOKENBUDDY_BUYER_STORE` 覆盖。

#### 2.8 运行测试 + 质量门禁

```bash
cargo test --workspace            # buyer-core / tb / seller-core …
cargo build --workspace
cargo clippy --workspace --all-targets -- -D warnings   # 0 warnings
bash scripts/p0_acceptance.sh     # 16/16 checks PASS
```

---

## 🔁 完整 E2E 验证链路

> 已在 dev 分支 commit `bd2b56a` (PR #2 squash-merged) 完整跑通；经 paseo loop 两轮独立 review（codex/gpt-5.4 worker + codex/gpt-5.5 verifier）判定 *"No critical or high findings remain"*。

| 步骤 | 命令 | 验证点 |
|------|------|--------|
| 1. doctor 自检 | `tb payment doctor --seller …` | buyer-core::ClawtipPreflight 三项 OK |
| 2. 启动 daemon | `tb-proxyd --bind-addr :17820` | RPC 控制面监听 |
| 3. 启动 proxy | `tb proxy start --listen :15721 …` | 通过 RPC 启动托管 proxy |
| 4. 首次 chat | `curl POST :15721/v1/chat/completions` | 真实 ClawTip 购买 + Qwen 输出 |
| 5. 第二次 chat | 同上 | `reuse cached seller token` 0 秒返回 |
| 6. probe seller | `tb seller probe --seller …` | contract v1 + manifest 完整 |
| 7. 全 workspace test | `cargo test --workspace` | 0 failed |
| 8. clippy 质量门 | `cargo clippy … -D warnings` | 0 warnings |

---

## 🪙 ClawTip 真实支付详细流程

> 前提：seller 配置了 `[clawtip]` 节，buyer 本机绑定了 ClawTip 钱包。

### 首次绑定本机钱包

```bash
export TOKENBUDDY_CLAWTIP_BIND_SM4_KEY_BASE64="$CLAWTIP_SM4_KEY"
export TOKENBUDDY_CLAWTIP_BIND_SKILL_SLUG="tokenbuddy-llm-console"
export TOKENBUDDY_CLAWTIP_BIND_SKILL_ID="si-tokenbuddy-llm-console"
tb payment add clawtip
```

CLI 会生成 1 分小额订单 → 调起京东扫码 → 轮询 `check-register` 直到本机钱包 ready，并把激活态写入 `~/.openclaw/configs/config.json`。

### `purchase buy` 自动购买

```bash
tb purchase buy \
  --seller http://127.0.0.1:8080 \
  --model-id qwen-plus \
  --request-key buy-001 \
  --amount-usd 0.01
```

自动完成：钱包就绪检查 → `purchase/create` → 写本地订单 → `npx @clawtip/clawtip-cli pay` → 读取 `payCredential` → `purchase/complete` → 缓存 access_token。

### 本地恢复 / 并发去重

- pending 状态记录在 `~/.tokenbuddy/buyer/agentpay-state.json`。
- 同一 (seller, model) 并发购买使用本机 single-flight 锁。
- 进程在已付款但未 complete 时退出，下次启动只 reconcile complete，不会重复 `pay`。
- 显式恢复：`tb purchase reconcile --seller $SELLER`

### Phase B: 手工分步购买

```bash
$BIN purchase create   --seller … --amount-usd 1.0 --request-key buy-001 --model-id qwen-plus
npx --yes @clawtip/clawtip-cli@1.0.1 pay -o <order_no> -i <indicator> -v 1.0.12
$BIN purchase complete --seller … --purchase-id pur_xxx --payment-proof "<payCredential>" --request-key buy-001-complete
```

---

## 🛠️ Seller 部署与运维

如果您是模型服务提供商，需要部署或运维卖家服务端，请参考独立的 [Seller 部署与运维指南](docs/seller-deployment.md) 来获取：
- 本地编译启动 `tb-seller` 卖家服务端
- Docker 容器化部署配置及官方 GHCR 镜像公开拉取设置说明
- 卖家端 SQLite 计费数据直接查询与 Token 状态现场运维命令
- 卖家端 HTTP 高并发架构和 SQLite 写入并发优化细节

---

## 📊 能力状态

| 能力 | 状态 |
|------|------|
| Seller 对接 OpenAI-compat 上游 | ✅ |
| Mock 支付购买信用 token | ✅ |
| ClawTip 京东真实支付（SM4 加密验证） | ✅ |
| Bearer token 授权 + tokenClass 撤销 | ✅ |
| 余额检查 / 耗尽拒绝推理 | ✅ |
| 幂等重试（相同 requestId） | ✅ |
| 容量限流（`busy_capacity`） | ✅ |
| 服务重启后状态完全恢复 | ✅ |
| SSE 流式 `/v1/chat/completions` / `/v1/responses` | ✅ |
| **buyer-core 共享库（TokenStore / ClawtipPreflight）** | ✅ Phase 2 |
| **Buyer Proxy（OpenAI 兼容反代 + 自动购买）** | ✅ |
| `/v1/messages` Anthropic 流式 | ❌ P1 |
| 多支付方式扩展（x402 等） | ❌ P1 |
| 第三方 seller 公共 registry | ❌ P1 |

---

## ⚡ 性能架构

**单节点并发**

- HTTP：axum + tokio 全异步
- DB：SQLite WAL，所有 DB 调用通过 `tokio::task::spawn_blocking` 隔离，不阻塞 tokio worker
- 全局 DB 并发信号量：128 permits
- 容量控制：`max_connections` + `max_queue_depth`
- SQLite pragma：`synchronous=FULL` + 32 MB page cache + 128 MB mmap

**多节点**

每个 seller 节点独立账本（SQLite）和独立上游。同一 Market 下可并行多节点对接不同供应商（OpenAI / Anthropic / DeepSeek / Qwen…），Buyer 通过 `/manifest` 路由。共享账本的真正水平扩展需外部 PostgreSQL，规划在 P2。

---

## 📚 文档

- [客户端前端 TokenBuddy 快速开始](README.md)
- [卖家服务端 Seller 部署与运维指南](docs/seller-deployment.md)
- [设计方案](docs/public-registry-TokenBuddy-design.md)
- [实施计划](docs/implementation-plan.md)
- [tb-proxyd 重构计划](docs/buyer-daemon-refactor-plan.md)
- [Buyer Proxy 迁移计划](docs/buyer-proxy-mode-migration-plan.md)
- [tb-wallet-bootstrap 钱包激活服务计划](docs/clawtip-wallet-bootstrap-service-plan.md)
- [Billing V2 设计](docs/billing-v2-design.md)
- [延迟工作 TODO](docs/TODOS.md)
- [Iroh 后续演进（参考）](docs/iroh-llm-seller-service-future-design.md)
